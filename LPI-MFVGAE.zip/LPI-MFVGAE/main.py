import argparse

import torch
import torch.nn as nn
import torch.nn.functional as F
import time
from sklearn.preprocessing import minmax_scale
from torch import device

from vgaemode import VGAEModel
from autils import *

parser = argparse.ArgumentParser()
parser.add_argument('--no-cuda', action='store_true', default=False,
                    help='Disables CUDA training.')
parser.add_argument('--seed', type=int, default=1, help='Random seed.')
parser.add_argument('--epochs', type=int, default=300,
                    help='Number of epochs to train.')
parser.add_argument('--lr', type=float, default=0.01,
                    help='Learning rate.')
parser.add_argument('--weight_decay', type=float, default=1e-7,
                    help='Weight decay (L2 loss on parameters).')
parser.add_argument('--hidden1', '-h1', type=int, default=512, help='Number of units in hidden layer 1.')
parser.add_argument('--alpha', type=float, default=0.5,
                    help='Weight between lncRNA space and protein space')
parser.add_argument('--beta', type=float, default=1,
                    help='Hyperparameter beta')
parser.add_argument('--gpu_id', type=int, default=0, help='GPU id to use.')
args = parser.parse_args()

args.cuda = not args.no_cuda and torch.cuda.is_available()
# device = torch.device("cuda:{}".format(args.gpu_id) if torch.cuda.is_available() else "cpu")
set_seed(args.seed, args.cuda)


# swl.csv swp.csv interaction.txt
# lpi2.csv
t = time.time()

mdi = np.loadtxt('./dataset1/Y.csv', delimiter=',')
mdit = torch.from_numpy(mdi).float()

rnafeat = np.loadtxt('./dataset1/lncRNA.csv', delimiter=',')
# rnafeat = minmax_scale(rnafeat, axis=0)
rnafeatorch = torch.from_numpy(rnafeat).float()

protfeat = np.loadtxt('./dataset1/protein.csv', delimiter=',')
# protfeat = minmax_scale(protfeat, axis=0)
protfeatorch = torch.from_numpy(protfeat)

gm = norm_adj(rnafeat)
gd = norm_adj(protfeat)
# gm = torch.from_numpy(rnafeat).float()
# gd = torch.from_numpy(protfeat).float()


if args.cuda:
    mdit = mdit.cuda()
    gm = gm.cuda()
    gd = gd.cuda()
    rnafeatorch = rnafeatorch.cuda()
    protfeatorch = protfeatorch.cuda()


class VGAEL(nn.Module):
    def __init__(self):
        super(VGAEL, self).__init__()
        self.vgael = VGAEModel(mdi.shape[1], args.hidden1)

    def forward(self, y0):
        yl,ml,ll,h = self.vgael(gm, y0)
        # yl, ml, ll, h = self.vgael(y0, gm)
        return yl,ml,ll,h


class VGAEP(nn.Module):
    def __init__(self):
        super(VGAEP, self).__init__()
        self.vgaep = VGAEModel(mdi.shape[0], args.hidden1)

    def forward(self, y0):
        yp,mp,lp,h = self.vgaep(gd, y0.t())
        # yp, mp, lp, h = self.vgaep(y0.t(), gd)
        return yp,mp,lp,h

def train(vgael, vgaep, y0, epoch, alpha):
    beta = args.beta
    optl = torch.optim.Adam(vgael.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    optp = torch.optim.Adam(vgaep.parameters(), lr=args.lr, weight_decay=args.weight_decay)

    for e in range(epoch):
        vgael.train()
        vgaep.train()

        yl,ml,ll,hl = vgael(y0)
        yp,mp,lp,hp = vgaep(y0)

        KLl = F.kl_div(yl.softmax(dim=-1).log(), y0.softmax(dim=-1), reduction='batchmean')
        KLp = F.kl_div(yp.softmax(dim=-1).log(), y0.t().softmax(dim=-1), reduction='batchmean')
        # KLl = 0
        # KLp = 0
        lossl = F.binary_cross_entropy(yl, y0)
        lossp = F.binary_cross_entropy(yp, y0.t())
        # lossl = 0
        # lossp = 0
        # loss1 = KLl + lossl
        # loss2 = KLp + lossp
        loss1 = 0.9*KLl + 0.1*lossl
        loss2 = 0.9*KLp + 0.1*lossp
        loss = beta * (alpha * loss1 + (1 - alpha) * loss2)


        optp.zero_grad()
        optl.zero_grad()
        loss.backward()
        optp.step()
        optl.step()
        vgaep.eval()
        vgael.eval()
        if e % 20 == 0 and e != 0:
            print('Epoch %d | Loss: %.4f' % (e, loss.item()))
        z = alpha * yl + (1 - alpha) * yp.t()
        z = z.cpu().detach().numpy()
        F1 = torch.zeros(y0.shape[0], y0.shape[1])
        F1=np.add(z[0:int(y0.shape[0]/2), 0:int(y0.shape[1]/2)],z[int(y0.shape[0]/2):y0.shape[0], int(y0.shape[1]/2):y0.shape[1]])
        F1=np.add(F1,z[0:int(y0.shape[0]/2), int(y0.shape[1]/2):y0.shape[1]])
        F1=np.add(F1,z[int(y0.shape[0]/2):y0.shape[0], 0:int(y0.shape[1]/2)])
        F1 = F1 / 4
        F1 = torch.tensor(F1)
    return F1


def trainres(A0):
    vgael = VGAEL()
    vgaep = VGAEP()
    if args.cuda:
        vgael = vgael.cuda()
        vgaep = vgaep.cuda()

    return train(vgael, vgaep, A0, args.epochs, args.alpha)


def fivefoldcv(A, alpha=0.5):
    N = int(A.shape[0]/2)
    idx = np.arange(N)
    np.random.shuffle(idx)
    aurocl = np.zeros(5)
    auprl = np.zeros(5)
    pl = np.zeros(5)
    rl = np.zeros(5)
    f1l = np.zeros(5)

    for i in range(5):
        print("Fold {}".format(i + 1))
        A0 = A.clone()
        for j in range(i * N // 5, (i + 1) * N // 5):
            A0[idx[j], :] = torch.zeros(A.shape[1])
            A0[idx[j]+N, :] = torch.zeros(A.shape[1])

        resi = trainres(A0)
        if args.cuda:
            resi = resi.cpu().detach().numpy()
        else:
            resi = resi.detach().numpy()

        auroc, aupr, p, r, f1 = show_auc(resi,i)
        aurocl[i] = auroc
        auprl[i] = aupr
        pl[i] = p
        rl[i] = r
        f1l[i] = f1
        print('AUROC= %.4f|AUPR= %.4f|recall=%.4f|prccision=%.4f|f1=%.4f' % (aurocl[i], auprl[i], rl[i], pl[i], f1l[i]))

    print("===Final result===")
    print('AUROC= %.4f +- %.4f | AUPR= %.4f +- %.4f' % (aurocl.mean(), aurocl.std(), auprl.mean(), auprl.std()))
    print(' recall= %.4f +- %.4f | precision= %.4f +- %.4f | f1score= %.4f +- %.4f' % (rl.mean(),rl.std(), pl.mean(),pl.std(), f1l.mean(),f1l.std()))
    print("time=", "{:.5f}".format(time.time() - t))


fivefoldcv(mdit, alpha=args.alpha)
