import torch
import torch.nn as nn
import torch.nn.functional as F


class GraphConv(nn.Module):
    def __init__(self, in_dim, out_dim, drop=0.5, bias=False, activation=None):
        super(GraphConv, self).__init__()
        self.dropout = nn.Dropout(drop)
        self.activation = activation
        self.w = nn.Linear(in_dim, out_dim, bias=bias)
        nn.init.xavier_uniform_(self.w.weight)
        self.bias = bias
        if self.bias:
            nn.init.zeros_(self.w.bias)

    def forward(self, adj, x):
        x = self.dropout(x)
        x = adj.mm(x)
        x = self.w(x)
        if self.activation:
            return self.activation(x)
        else:
            return x


class VGAEModel(nn.Module):
    def __init__(self, in_dim, hidden1_dim):
        super(VGAEModel, self).__init__()
        self.in_dim = in_dim
        self.hidden1_dim = hidden1_dim
        self.hidden2_dim = in_dim
        layers = [GraphConv(self.in_dim, self.hidden1_dim, activation=F.relu),
                  GraphConv(self.hidden1_dim, self.hidden2_dim, activation=lambda x: x),  # lambda x: x
                  GraphConv(self.hidden1_dim, self.hidden2_dim, activation=lambda x: x)]
        self.layers = nn.ModuleList(layers)

    def encoder(self, g, features):
        h = self.layers[0](g, features)
        mean = self.layers[1](g, h)
        log_std = self.layers[2](g, h)
        gaussian_noise = torch.randn(features.size(0), self.hidden2_dim).cuda()
        sampled_z = mean + gaussian_noise * torch.exp(log_std).cuda()
        return sampled_z, mean, log_std,h

    def forward(self, g, features):
        z, m, l, h = self.encoder(g, features)
        z = torch.sigmoid(z)
        return z, m, l, h
